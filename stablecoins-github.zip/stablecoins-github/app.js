/* ═══════════════════════════════════════════
   STABLECOINS — app.js
   Navigation + Chart.js initialisation
   ═══════════════════════════════════════════ */

const TOTAL = 13;
let current = 1;

// ─── Navigation ──────────────────────────────────────────────
function goTo(n) {
  if (n < 1 || n > TOTAL) return;

  const prev = document.querySelector('.slide.active');
  if (prev) prev.classList.remove('active');

  current = n;

  const next = document.querySelector(`.slide[data-slide="${n}"]`);
  if (next) next.classList.add('active');

  // Update counter
  document.getElementById('slideCounter').textContent = `${current} / ${TOTAL}`;

  // Update progress bar
  const pct = ((current - 1) / (TOTAL - 1)) * 100;
  document.getElementById('progressBar').style.width = pct + '%';

  // Buttons
  document.getElementById('prevBtn').disabled = current === 1;
  document.getElementById('nextBtn').disabled = current === TOTAL;

  // Init chart if we're on slide 4
  if (current === 4) initPieChart();
}

function changeSlide(dir) {
  goTo(current + dir);
}

// ─── Keyboard navigation ─────────────────────────────────────
document.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowRight' || e.key === 'ArrowDown' || e.key === ' ') {
    e.preventDefault();
    changeSlide(1);
  } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
    e.preventDefault();
    changeSlide(-1);
  } else if (e.key === 'f' || e.key === 'F') {
    toggleFullscreen();
  }
});

// ─── Touch / swipe ───────────────────────────────────────────
let touchStartX = 0;
document.addEventListener('touchstart', (e) => { touchStartX = e.changedTouches[0].screenX; });
document.addEventListener('touchend', (e) => {
  const dx = e.changedTouches[0].screenX - touchStartX;
  if (Math.abs(dx) > 50) changeSlide(dx < 0 ? 1 : -1);
});

// ─── Fullscreen ───────────────────────────────────────────────
function toggleFullscreen() {
  const icon = document.getElementById('fsIcon');
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen().catch(() => {});
    icon.className = 'fa-solid fa-compress';
  } else {
    document.exitFullscreen();
    icon.className = 'fa-solid fa-expand';
  }
}

// ─── Pie Chart (Slide 4) ──────────────────────────────────────
let pieChartInstance = null;

function initPieChart() {
  const canvas = document.getElementById('pieChart');
  if (!canvas || pieChartInstance) return;

  pieChartInstance = new Chart(canvas, {
    type: 'doughnut',
    data: {
      labels: ['Bons du Trésor US', 'Cash & dépôts', 'Autres'],
      datasets: [{
        data: [80, 17, 3],
        backgroundColor: ['#0D9488', '#F59E0B', '#CBD5E1'],
        borderWidth: 2,
        borderColor: '#F8FAFC',
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'right',
          labels: {
            font: { family: 'DM Sans', size: 11 },
            color: '#334155',
            padding: 12,
          }
        },
        tooltip: {
          callbacks: {
            label: (ctx) => ` ${ctx.label}: ${ctx.raw}%`
          }
        }
      }
    }
  });
}

// ─── Hide keyboard hint after 4s ─────────────────────────────
setTimeout(() => {
  const hint = document.querySelector('.keyboard-hint');
  if (hint) hint.style.opacity = '0';
}, 4000);

// ─── Init ─────────────────────────────────────────────────────
goTo(1);
