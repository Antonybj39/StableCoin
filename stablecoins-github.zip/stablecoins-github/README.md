# 💰 Les Stablecoins — Présentation interactive

Présentation web sur les stablecoins : définition, usages économiques et réponses réglementaires.

## 🚀 Déploiement sur GitHub Pages

### Étape 1 — Créer le dépôt
1. Connectez-vous à [github.com](https://github.com)
2. Cliquez sur **"New repository"**
3. Nommez-le `stablecoins-presentation` (ou ce que vous voulez)
4. Cochez **"Public"**
5. Cliquez **"Create repository"**

### Étape 2 — Uploader les fichiers
1. Dans votre nouveau dépôt, cliquez **"uploading an existing file"**
2. Glissez-déposez les 3 fichiers :
   - `index.html`
   - `style.css`
   - `app.js`
3. Cliquez **"Commit changes"**

### Étape 3 — Activer GitHub Pages
1. Allez dans **Settings** → **Pages**
2. Dans *"Source"*, sélectionnez **"Deploy from a branch"**
3. Choisissez la branche **`main`** et le dossier **`/ (root)`**
4. Cliquez **"Save"**

Votre présentation sera accessible à l'adresse :
```
https://VOTRE_USERNAME.github.io/stablecoins-presentation/
```

---

## ⌨️ Contrôles

| Action | Raccourci |
|--------|-----------|
| Slide suivante | `→` ou `Espace` |
| Slide précédente | `←` |
| Plein écran | `F` ou bouton ⛶ |
| Navigation tactile | Swipe gauche / droite |

---

## 📋 Contenu (13 slides)

1. **Titre** — Statistiques clés
2. **Sommaire** — 5 parties
3. **Définition** — 3 familles de stablecoins
4. **USDC en pratique** — Flux + graphique des réserves
5. **Usages concrets** — 4 cas d'usage expliqués simplement
6. **Effets positifs** — Réduction des frictions, inclusion, innovation
7. **Risques** — 4 types de risques avec exemples chiffrés
8. **Bank run numérique** — Cascade en 5 étapes
9. **Ce que les États pensent** — UE, États-Unis, Asie
10. **La BCE face aux stablecoins** — Position détaillée + verdict
11. **Tableau comparatif** — Approches réglementaires
12. **Synthèse** — 4 points clés
13. **Merci** — Sources

---

## 🛠 Technologies

- HTML5 / CSS3 / JavaScript vanilla
- [Chart.js](https://chartjs.org) pour le graphique (CDN)
- [Font Awesome 6](https://fontawesome.com) pour les icônes (CDN)
- [Google Fonts](https://fonts.google.com) — Sora + DM Sans
